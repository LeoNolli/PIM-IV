﻿namespace PIM_Fazenda_Urbana.Models
{
    public class InsumoProducao
    {
        public int ProducaoId { get; set; }
        public int InsumoId { get; set; }
        public int Quantidade { get; set; }
    }
}
