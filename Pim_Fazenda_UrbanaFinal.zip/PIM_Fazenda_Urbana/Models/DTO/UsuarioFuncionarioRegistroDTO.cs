﻿namespace PIM_Fazenda_Urbana.Models.DTO
{
    public class UsuarioFuncionarioRegistroDTO : UsuarioRegistroDTO
    {
        public string Cargo { get; set; }
    }
}
